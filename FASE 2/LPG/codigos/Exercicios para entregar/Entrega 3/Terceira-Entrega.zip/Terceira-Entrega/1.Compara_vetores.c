/*Escreva uma funcao que recebe dois vetores de mesma capacidade n e compara se os mesmos sao iguais, ou seja, se contem os mesmos valores e na mesma ordem. A funcaodeve ser booleana, ou seja, se forem iguais retorna 1, caso contrario retorna 0. Prototipo da funcao:
int compara(float a[], float b[], int n)*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int compara(float a[], float b[], int n){
    for (int i = 0; i < n; i++){
        if (a[i]!=b[i]) return 0;
    }
    return 1;
}

int main(){

    int tam, num;
    puts("Digite o tamanho dos vetores:");
    scanf("%i", &tam);

    float vetorA[tam];
    float vetorB[tam];
    
    puts("Digite o vetor A:");
    for (int i = 0; i < tam; i++){
    	scanf("%i", &num);
	vetorA[i] = num;
    }
	
    puts("Digite o vetor B:");
    for (int i = 0; i < tam; i++){
    	scanf("%i", &num);
	vetorB[i] = num;
    }

    printf("%s\n", compara(vetorA, vetorB, tam)? "Vetores A e B iguais" : "Vetores A e B nao sao iguais" );


return 0;
}

